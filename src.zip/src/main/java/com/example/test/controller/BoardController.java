package com.example.test.controller;

import com.example.test.dto.Datatable;
import com.example.test.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequiredArgsConstructor
public class BoardController {

    private final BoardService boardService;

    @GetMapping("/board/list")
    public String list(){return "board/list";}

    @GetMapping("/board/list-data")
    @ResponseBody
    public Datatable getList(){ return boardService.findAll(); }
}


