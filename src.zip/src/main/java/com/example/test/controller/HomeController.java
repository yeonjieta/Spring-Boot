package com.example.test.controller;

import com.example.test.service.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

// 생성자 주입을 해야하는데 RequiredArgsConstructor 를 써주면 바로 인식한다.
// 생성자 주입을 안하면 나타나는 삼각 참조 형태(서로가 서로를 참조하는 - 순환참조) 현상을 방지하기 위해
// autowired 역할 수행
@Controller
@RequiredArgsConstructor
public class HomeController {
    // 바로 생성자 주입
    private final BoardService boardService;

    @GetMapping("/")
    public String home(){ return "home"; }

}
