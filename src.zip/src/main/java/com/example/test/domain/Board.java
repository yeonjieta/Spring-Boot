package com.example.test.domain;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;

import java.time.LocalDateTime;

// Entity - table이랑 직접 연결돼있음 (Service 까지만 사용)
@Entity
@Getter
@Table(name="BOARD2", schema = "JPATEST_YJ" )
public class Board {
    @Id //기본키
    @Column(name="IDX")
    private long Idx;

    @Column(name="TITLE")
    private String title;

    @Column(name="WRITER")
    private String writer;

    @Column(name="CONTENT")
    private String content;

    @Column(name="WRITEDATE")
    private LocalDateTime writeDate;


}
