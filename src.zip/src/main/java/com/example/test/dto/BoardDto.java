package com.example.test.dto;

import com.example.test.domain.Board;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

// NoArgsConstructor : 기본생성자가 생성 가능함
@Data
@NoArgsConstructor
public class BoardDto {
    private Long idx;
    private String title;
    private String writer;
    private String content;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime writeDate;

    public BoardDto(Board entity) {
        this.idx = entity.getIdx();
        this.title = entity.getTitle();
        this.writer = entity.getWriter();
        this.content = entity.getContent();
        this.writeDate = entity.getWriteDate();
    }
// Service에서 데이터베이스로부터 조회된 Board 엔티티 리스트를
// 클라이언트에 전송하기 적합한 형태로 변환하는 데 사용
    public static List<BoardDto> ListToDto(List<Board> list){
        List<BoardDto> dtoList = new ArrayList<>();
        list.forEach(entity -> dtoList.add(new BoardDto(entity)));

        return dtoList;
    }
}
