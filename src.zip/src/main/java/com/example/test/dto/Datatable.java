package com.example.test.dto;

import lombok.Data;

import java.util.List;

// 어떠한 클래스가 와도 다 받아주겠다 = T
@Data
public class Datatable<T> {
    List<T> data;

    // Setter 로 하면 안받아지기 때문에 생성자로
    public Datatable(List<T> data) {
        this.data = data;
    }
}
