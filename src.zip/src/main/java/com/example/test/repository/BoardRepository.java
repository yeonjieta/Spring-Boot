package com.example.test.repository;

import com.example.test.domain.Board;
import org.springframework.data.jpa.repository.JpaRepository;

// JpaRepository 통해서 Board 테이블을 다 가져온다
public interface BoardRepository extends JpaRepository<Board, Long> {
}
