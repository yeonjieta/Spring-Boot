package com.example.test.service;

import com.example.test.domain.Board;
import com.example.test.dto.BoardDto;
import com.example.test.dto.Datatable;
import com.example.test.repository.BoardRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardRepository boardRepository;

    public Datatable findAll(){
        return new Datatable(BoardDto.ListToDto(boardRepository.findAll()));
    }

}





