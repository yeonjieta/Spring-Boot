let dataTable;

$(document).ready(function(){
    getData();
})

function getData() {
    dataTable = $('#dataTable').DataTable({
        "ajax": {
            url: "/board/list-data",
            type: "GET",
        },
        columns: [
            {data: "idx"},
            {
                data: "title",
                render: function (data, type, row){
                    const url = "/board/view/" + row.idx;
                    return '<a th:href ="' + url + '" >' + data + '</a>'
                }
            },
            {data: "writer"},
            {data: "writeDate"}
        ],

        // bootstrap
        destroy: true,
        paging: true,

    });



}